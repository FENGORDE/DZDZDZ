# Create your views here.
class BaseRegisterView:
    pass